INSERT INTO npcs (npcname, givinggifttoday) VALUES ('Abigail', FALSE);
INSERT INTO npcs (npcname, givinggifttoday) VALUES ('Alex', FALSE);
INSERT INTO npcs (npcname, givinggifttoday) VALUES ('Caroline', FALSE);
INSERT INTO npcs (npcname, givinggifttoday) VALUES ('Clint', FALSE);
INSERT INTO npcs (npcname, givinggifttoday) VALUES ('Demetrius', FALSE);
INSERT INTO npcs (npcname, givinggifttoday) VALUES ('Dwarf', FALSE);
INSERT INTO npcs (npcname, givinggifttoday) VALUES ('Elliott', FALSE);
INSERT INTO npcs (npcname, givinggifttoday) VALUES ('Emily', FALSE);
INSERT INTO npcs (npcname, givinggifttoday) VALUES ('Evelyn', FALSE);
INSERT INTO npcs (npcname, givinggifttoday) VALUES ('George', FALSE);

